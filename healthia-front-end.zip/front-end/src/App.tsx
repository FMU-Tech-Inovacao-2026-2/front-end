import { lazy, Suspense } from 'react'
import { Navigate, Route, Routes } from 'react-router'
import { RotaProtegida } from './auth/RotaProtegida'
import Entrar from './pages/Entrar'

// O início só é baixado depois do login.
const Inicio = lazy(() => import('./pages/Inicio'))

export function Rotas() {
  return (
    <Routes>
      <Route path="/entrar" element={<Entrar />} />
      <Route
        path="/"
        element={
          <RotaProtegida>
            <Suspense fallback={<p role="status" className="p-8 text-texto-suave">Carregando…</p>}>
              <Inicio />
            </Suspense>
          </RotaProtegida>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
