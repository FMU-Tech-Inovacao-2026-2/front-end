import { useEffect } from 'react'
import { useNavigate } from 'react-router'
import { useAuth } from '../auth/AuthProvider'
import type { Perfil } from '../auth/tipos'
import { LogoHealthIA } from '../components/Logo'

interface Modulo {
  nome: string
  descricao: string
}

// Provisório: a home de verdade vem na próxima etapa. Os módulos ainda não têm rota.
const MODULOS: Record<Perfil, Modulo[]> = {
  profissional: [
    { nome: 'Alta Assistida', descricao: 'Transforma o sumário de alta num plano de cuidados que o paciente segue em casa.' },
    { nome: 'Prescrição Assistida', descricao: 'Estrutura a prescrição, confere a origem de cada item e avisa sobre alergias.' },
    { nome: 'Paciente Assistido', descricao: 'Chat com o histórico do paciente, sempre com a fonte de cada resposta.' },
  ],
  paciente: [
    { nome: 'Meu plano de cuidados', descricao: 'Remédios, cuidados e retornos aprovados pela sua equipe de saúde.' },
  ],
}

export default function Inicio() {
  const { usuario, sair } = useAuth()
  const navegar = useNavigate()

  useEffect(() => {
    document.title = 'Início · HealthIA'
  }, [])

  if (!usuario) return null
  const profissional = usuario.perfil === 'profissional'

  async function sairDaConta() {
    await sair()
    navegar('/entrar', { replace: true })
  }

  return (
    <div className="min-h-dvh">
      <header className="flex flex-wrap items-center justify-between gap-4 border-b bg-white px-6 py-3.5">
        <LogoHealthIA />
        <div className="flex items-center gap-4 text-sm">
          <span className="text-texto-suave">{usuario.email}</span>
          <button
            type="button"
            onClick={sairDaConta}
            className="min-h-11 rounded-lg border border-borda-campo px-4 font-semibold hover:bg-superficie focus-visible:outline-hidden focus-visible:ring-3 focus-visible:ring-destaque/40"
          >
            Sair
          </button>
        </div>
      </header>
      <main id="conteudo" className="mx-auto flex max-w-205 flex-col gap-6 px-5 py-11">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold">{profissional ? 'Olá, profissional' : 'Olá'}</h1>
          <p className="text-base text-texto-suave">
            {profissional
              ? 'Escolha um módulo para começar.'
              : 'Aqui você acompanha o plano de cuidados aprovado pela sua equipe de saúde.'}
          </p>
        </div>
        <ul className="flex flex-col gap-3">
          {MODULOS[usuario.perfil].map((modulo) => (
            <li key={modulo.nome} className="flex flex-col gap-1 rounded-xl border bg-white p-5">
              <h2 className="text-lg font-semibold">{modulo.nome}</h2>
              <p className="text-[0.9375rem] leading-snug text-texto-suave">{modulo.descricao}</p>
              <p className="text-sm font-semibold text-destaque-escuro">Em construção</p>
            </li>
          ))}
        </ul>
      </main>
    </div>
  )
}
