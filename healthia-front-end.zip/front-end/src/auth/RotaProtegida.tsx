import type { ReactNode } from 'react'
import { Navigate, useLocation } from 'react-router'
import { useAuth } from './AuthProvider'

export function RotaProtegida({ children }: { children: ReactNode }) {
  const { usuario, carregando } = useAuth()
  const local = useLocation()

  if (carregando) {
    return (
      <p role="status" className="p-8 text-texto-suave">
        Carregando…
      </p>
    )
  }
  if (!usuario) return <Navigate to="/entrar" replace state={{ voltarPara: local.pathname }} />
  return <>{children}</>
}
