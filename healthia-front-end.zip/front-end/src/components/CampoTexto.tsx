import { useId, type InputHTMLAttributes, type ReactNode, type Ref } from 'react'

interface Props extends Omit<InputHTMLAttributes<HTMLInputElement>, 'id' | 'className'> {
  rotulo: string
  erro?: string
  /** Conteúdo à direita do campo, como o botão de mostrar senha. */
  acessorio?: ReactNode
  ref?: Ref<HTMLInputElement>
}

export function CampoTexto({ rotulo, erro, acessorio, ref, ...input }: Props) {
  const id = useId()
  const idErro = `${id}-erro`
  const temErro = Boolean(erro)

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-[0.9375rem] font-semibold">
        {rotulo}
      </label>
      <div className="relative flex">
        <input
          {...input}
          id={id}
          ref={ref}
          aria-invalid={temErro}
          aria-describedby={temErro ? idErro : undefined}
          className={`min-h-12 w-full min-w-0 rounded-lg bg-white px-3.5 text-base text-marca placeholder:text-texto-suave focus-visible:outline-hidden focus-visible:ring-3 focus-visible:ring-destaque/40 ${
            acessorio ? 'pr-24' : ''
          } ${temErro ? 'border-2 border-erro focus-visible:border-erro' : 'border border-borda-campo focus-visible:border-destaque'}`}
        />
        {acessorio}
      </div>
      {temErro ? (
        <p id={idErro} className="entrada-erro-campo flex items-center gap-1.5 text-sm text-erro">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className="shrink-0">
            <circle cx="12" cy="12" r="9" />
            <path d="M12 8v5M12 16h.01" />
          </svg>
          {erro}
        </p>
      ) : null}
    </div>
  )
}
